# Jarvis — Voice Pipeline (v1)

This is step 1 of your personal assistant build: the voice input/output layer.
STT (hearing you) is `faster-whisper`. TTS (speaking to you) is `Piper`, with
5 switchable voices.

Everything here runs **locally on your own PC** — no cloud cost for voice.
The only API cost comes later, once we plug in Claude for the "brain" part
(deciding what to do / say).

## Setup (one-time, on your Windows PC)

1. Install Python 3.10+ if you don't have it: https://python.org
2. Open a terminal in this folder and run:
   ```
   pip install -r requirements.txt
   ```
3. Download the 5 voices (one-time, ~200MB total, needs internet):
   ```
   python scripts/download_voices.py
   ```

## Try it

**Test a voice speaking something:**
```
python scripts/tts.py "Good morning, sir. You have a meeting in twenty minutes." --voice ryan --play
```
Try `--voice amy`, `ryan`, `alan`, `lessac`, or `southern` to hear each one.

**Test transcribing a recording:**
```
python scripts/stt.py path/to/some_audio.wav
```

**Full loop (mic in → text → text → speech out):**
```
python scripts/listen_and_respond.py --voice amy
```
Press ENTER, say something, press ENTER again, and Jarvis will transcribe
it and read it back. Right now the "thinking" part is a placeholder — it
just repeats what you said. That's the next piece we wire in: the Claude
API call that actually decides what Jarvis should do or say.

## The 5 voices

| Name | Voice | Character |
|---|---|---|
| `amy` | en_US-amy-medium | US female, warm, default |
| `ryan` | en_US-ryan-high | US male, clear, highest quality |
| `alan` | en_GB-alan-medium | UK male, crisp British |
| `lessac` | en_US-lessac-medium | US neutral, calm narrator |
| `southern` | en_GB-southern_english_female-low | UK female, soft |

You can add more any time from the full Piper voice list:
https://github.com/OHF-voice/piper1-gpl/blob/main/VOICES.md
(just add the voice ID to `download_voices.py` and `VOICE_FILES` in `tts.py`)

## What's next
1. ✅ Voice pipeline (this step)
2. ⬜ Brain: wire in the Claude API so it actually understands commands and
   responds intelligently, with memory of context
3. ⬜ Computer control: let it click/type/see your screen for automation
4. ⬜ Calendar + project integrations: meeting reminders, project status
   (this is the client's main need)
